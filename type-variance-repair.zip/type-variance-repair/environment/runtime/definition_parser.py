"""
Definition Parser — Reads type hierarchy and function definitions.

Parses type_definitions.txt into structured data for the type registry
and variance checker.

This module is correct — no bugs here.
"""

import os

DEFS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "type_definitions.txt")


def parse_definitions(filepath=None):
    """
    Parse the type definitions file.

    Returns:
        types: list of (name, parents) tuples
        functions: list of (name, {"params": [...], "returns": type}) tuples
    """
    if filepath is None:
        filepath = DEFS_FILE

    types = []
    functions = []

    with open(filepath, "r") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if line.startswith("TYPE "):
                parts = line.split()
                # TYPE <name> EXTENDS <parent1>,<parent2>,...
                name = parts[1]
                parents = []
                if len(parts) > 3 and parts[3]:
                    parents = [p.strip() for p in parts[3].split(",") if p.strip()]
                types.append((name, parents))

            elif line.startswith("FUNC "):
                # FUNC <name> PARAMS <t1>,<t2>,... RETURNS <type>
                parts = line.split()
                name = parts[1]
                # Find PARAMS and RETURNS indices
                params_idx = parts.index("PARAMS")
                returns_idx = parts.index("RETURNS")
                params_str = " ".join(parts[params_idx + 1:returns_idx])
                params = [p.strip() for p in params_str.split(",") if p.strip()]
                returns = parts[returns_idx + 1]
                functions.append((name, {"params": params, "returns": returns}))

    return types, functions
