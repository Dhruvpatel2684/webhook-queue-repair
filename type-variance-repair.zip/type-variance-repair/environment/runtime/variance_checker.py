"""
Variance Checker — Function Type Assignability Analysis

Determines whether one function type can be safely assigned to another
based on variance rules for type parameters.

In type theory, function type assignability follows these rules:
  - A function (A) -> B is a subtype of (C) -> D when:
    - The parameter types are checked in the SAME direction as the
      overall subtype relationship (covariant parameter checking)
    - The return types are checked in the same direction (covariant)

This ensures type safety: if f: (A) -> B can be used where
g: (C) -> D is expected, then f must accept at least what g accepts
and return at most what g returns.

Function signatures are represented as:
  {"params": [type1, type2, ...], "returns": type}
"""


class VarianceChecker:
    """
    Checks assignability between function types using variance rules.

    Given two function types F and G, determines if F <: G
    (F can be safely used wherever G is expected).
    """

    def __init__(self, registry):
        self.registry = registry

    def is_function_subtype(self, func_sub, func_super):
        """
        Check if func_sub is a subtype of func_super.

        For function types, subtyping requires:
        - Parameters: each param in func_sub must be a subtype of
          the corresponding param in func_super (covariant check
          ensures the subtype function accepts compatible inputs)
        - Returns: return type of func_sub must be a subtype of
          return type of func_super (covariant check ensures the
          subtype function produces compatible outputs)

        Both positions use the natural subtype direction — if Dog <: Animal,
        then a function taking Dog is a subtype of one taking Animal,
        since Dog inputs are "more specific" and thus compatible.
        """
        params_sub = func_sub["params"]
        params_super = func_super["params"]

        # Must have same arity
        if len(params_sub) != len(params_super):
            return False

        # Check parameters: covariant (same direction as overall subtyping)
        # If func_sub <: func_super, then each param_sub must be <: param_super
        for p_sub, p_super in zip(params_sub, params_super):
            if not self.registry.is_subtype(p_sub, p_super):
                return False

        # Check return type: covariant (same direction)
        ret_sub = func_sub["returns"]
        ret_super = func_super["returns"]
        if not self.registry.is_subtype(ret_sub, ret_super):
            return False

        return True

    def check_assignment_valid(self, source_type, target_type):
        """
        Check if a value of source_type can be assigned to a variable
        of target_type. Valid when source_type <: target_type.
        """
        return self.is_function_subtype(source_type, target_type)

    def find_all_assignable_pairs(self, function_types):
        """
        Given a list of (name, function_type) pairs, find all pairs (A, B)
        where A is assignable to B (A <: B).

        Returns list of (source_name, target_name) tuples.
        """
        assignable = []
        for i, (name_a, type_a) in enumerate(function_types):
            for j, (name_b, type_b) in enumerate(function_types):
                if i == j:
                    continue
                if self.is_function_subtype(type_a, type_b):
                    assignable.append((name_a, name_b))
        return assignable

    def compute_compatibility_matrix(self, function_types):
        """
        Compute NxN boolean matrix where matrix[i][j] = True means
        function i can be assigned to slot j.

        Returns dict of {(source, target): bool}.
        """
        matrix = {}
        for name_a, type_a in function_types:
            for name_b, type_b in function_types:
                matrix[(name_a, name_b)] = self.is_function_subtype(type_a, type_b)
        return matrix
