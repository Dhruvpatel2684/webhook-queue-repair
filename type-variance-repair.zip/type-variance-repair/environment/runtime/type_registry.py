"""
Type Registry — Hierarchical Type System Definition

Defines the type hierarchy and provides subtype relationship queries.
Types form a DAG (directed acyclic graph) where edges represent
"is subtype of" relationships.

This module is correct — no bugs here.
"""


class TypeRegistry:
    """
    Maintains the type hierarchy as a directed graph.
    Edge A -> B means "A is a subtype of B" (A <: B).
    """

    def __init__(self):
        self.supertypes = {}   # type -> set of direct supertypes
        self.subtypes = {}     # type -> set of direct subtypes
        self._reachable_cache = {}

    def register_type(self, type_name, parents=None):
        """Register a type with its direct supertypes."""
        if type_name not in self.supertypes:
            self.supertypes[type_name] = set()
            self.subtypes[type_name] = set()
        if parents:
            for parent in parents:
                if parent not in self.supertypes:
                    self.supertypes[parent] = set()
                    self.subtypes[parent] = set()
                self.supertypes[type_name].add(parent)
                self.subtypes[parent].add(type_name)
        self._reachable_cache.clear()

    def is_subtype(self, child, parent):
        """
        Check if child <: parent (child is subtype of parent).
        Uses transitive closure — follows the subtype chain upward.
        A type is always a subtype of itself (reflexive).
        """
        if child == parent:
            return True
        return parent in self._get_all_supertypes(child)

    def _get_all_supertypes(self, type_name):
        """
        Compute the transitive closure of the type hierarchy for a given type.
        Traverses the subtype edges to collect all types in the hierarchy
        chain that this type participates in below its position.
        """
        if type_name in self._reachable_cache:
            return self._reachable_cache[type_name]

        visited = set()
        stack = list(self.subtypes.get(type_name, set()))
        while stack:
            current = stack.pop()
            if current not in visited:
                visited.add(current)
                stack.extend(self.subtypes.get(current, set()))

        self._reachable_cache[type_name] = visited
        return visited

    def get_all_types(self):
        """Return all registered types."""
        return set(self.supertypes.keys())

    def get_direct_supertypes(self, type_name):
        """Get immediate parent types."""
        return self.supertypes.get(type_name, set())

    def get_direct_subtypes(self, type_name):
        """Get immediate child types."""
        return self.subtypes.get(type_name, set())
