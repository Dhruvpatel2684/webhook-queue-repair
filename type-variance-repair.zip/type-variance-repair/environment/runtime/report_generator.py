"""
Report Generator — Type Compatibility Analysis Output

Produces assignability_report.json with:
- Per-function type information
- Full compatibility matrix
- Assignable pair list
- Summary statistics
- Integrity fingerprint
"""

import json
import hashlib
import os


def compute_fingerprint(assignable_pairs, matrix_true_count, function_count):
    """
    Compute deterministic integrity fingerprint from analysis results.
    """
    data = f"pairs:{len(assignable_pairs)};"
    data += f"matrix_true:{matrix_true_count};"
    data += f"functions:{function_count};"
    for src, tgt in sorted(assignable_pairs):
        data += f"{src}->{tgt}|"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def generate_report(function_types, assignable_pairs, compat_matrix, output_dir):
    """
    Write the assignability analysis report.

    Produces assignability_report.json with full analysis results.
    """
    # Count True entries in matrix (excluding self-assignments)
    matrix_true_count = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src != tgt
    )

    # Self-assignable count (should be all functions)
    self_assignable = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src == tgt
    )

    function_count = len(function_types)
    total_pairs = function_count * (function_count - 1)

    fingerprint = compute_fingerprint(
        assignable_pairs, matrix_true_count, function_count
    )

    # Build per-function info
    func_info = {}
    for name, ftype in function_types:
        assignable_to = sorted([tgt for src, tgt in assignable_pairs if src == name])
        assignable_from = sorted([src for src, tgt in assignable_pairs if tgt == name])
        func_info[name] = {
            "params": ftype["params"],
            "returns": ftype["returns"],
            "assignable_to": assignable_to,
            "assignable_from": assignable_from,
        }

    report = {
        "function_count": function_count,
        "total_possible_pairs": total_pairs,
        "assignable_pair_count": len(assignable_pairs),
        "assignable_pairs": sorted([f"{s}->{t}" for s, t in assignable_pairs]),
        "self_assignable_count": self_assignable,
        "matrix_true_count": matrix_true_count,
        "functions": func_info,
        "fingerprint": fingerprint,
    }

    report_path = os.path.join(output_dir, "assignability_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    return report_path
