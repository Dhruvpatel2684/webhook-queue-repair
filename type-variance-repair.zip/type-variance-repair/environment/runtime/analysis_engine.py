"""
Type Variance Analysis Engine — Main Entry Point

Orchestrates the type compatibility analysis pipeline:
1. Parse type definitions
2. Build type registry (hierarchy)
3. Run variance checker (function assignability)
4. Generate compatibility report

Usage: python3 analysis_engine.py

Reads: type_definitions.txt
Produces: assignability_report.json
"""

import os
import sys

RUNTIME_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, RUNTIME_DIR)

from definition_parser import parse_definitions
from type_registry import TypeRegistry
from variance_checker import VarianceChecker
from report_generator import generate_report


def main():
    """Main execution: parse types, check variance, write report."""
    defs_path = os.path.join(RUNTIME_DIR, "type_definitions.txt")
    types, functions = parse_definitions(defs_path)

    print(f"Loaded {len(types)} types and {len(functions)} function definitions")

    # Build type registry
    registry = TypeRegistry()
    for name, parents in types:
        registry.register_type(name, parents)

    print(f"Type registry: {len(registry.get_all_types())} types registered")

    # Run variance analysis
    checker = VarianceChecker(registry)
    assignable_pairs = checker.find_all_assignable_pairs(functions)
    compat_matrix = checker.compute_compatibility_matrix(functions)

    print(f"Analysis complete: {len(assignable_pairs)} assignable pairs found")

    # Generate report
    report_path = generate_report(
        function_types=functions,
        assignable_pairs=assignable_pairs,
        compat_matrix=compat_matrix,
        output_dir=RUNTIME_DIR,
    )

    print(f"Output written: {report_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
