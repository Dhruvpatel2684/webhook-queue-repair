"""
Tests for type-variance-repair task.
Validates the function type assignability analysis output.
"""

import json
import os


RUNTIME_DIR = "/app/runtime"
REPORT_PATH = os.path.join(RUNTIME_DIR, "assignability_report.json")


def load_report():
    """Load assignability_report.json and return dict."""
    with open(REPORT_PATH, "r") as f:
        return json.load(f)


# ============================================================
# TIER 1: Basic structure (pass even with buggy code)
# ============================================================

def test_report_exists():
    """Report file must be created."""
    assert os.path.exists(REPORT_PATH), "assignability_report.json not found"


def test_function_count():
    """Report must contain exactly 20 function definitions."""
    report = load_report()
    assert report["function_count"] == 20, (
        f"Expected 20 functions, got {report['function_count']}"
    )


def test_total_possible_pairs():
    """Total possible pairs must be 20*19=380."""
    report = load_report()
    assert report["total_possible_pairs"] == 380, (
        f"Expected 380, got {report['total_possible_pairs']}"
    )


def test_self_assignable():
    """Every function type must be assignable to itself (reflexive)."""
    report = load_report()
    assert report["self_assignable_count"] == 20, (
        f"Expected 20 self-assignable, got {report['self_assignable_count']}"
    )


def test_report_has_functions():
    """Report must contain per-function analysis for all 20 functions."""
    report = load_report()
    assert "functions" in report
    assert len(report["functions"]) == 20


def test_known_non_assignable():
    """xml_handler should NOT be assignable to integer_processor (unrelated types)."""
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "xml_handler->integer_processor" not in pairs
    assert "integer_processor->xml_handler" not in pairs


def test_assignable_pairs_is_list():
    """Assignable pairs must be a sorted list of strings in 'A->B' format."""
    report = load_report()
    pairs = report["assignable_pairs"]
    assert isinstance(pairs, list)
    assert pairs == sorted(pairs), "Pairs must be sorted"
    for p in pairs:
        assert "->" in p, f"Invalid pair format: {p}"


# ============================================================
# TIER 2: Medium (requires understanding variance direction)
# ============================================================

def test_assignable_pair_count():
    """Correct variance analysis must find exactly 29 assignable pairs."""
    report = load_report()
    assert report["assignable_pair_count"] == 29, (
        f"Expected 29 assignable pairs, got {report['assignable_pair_count']}. "
        f"Function parameters are CONTRAVARIANT: when checking if F <: G, "
        f"the parameter types of G must be subtypes of F's parameters (reversed)."
    )


def test_broad_collector_assignable_to_narrow():
    """broad_collector (params: Top) should be assignable to narrow_collector (params: List).

    With contravariant parameters: broad_collector <: narrow_collector requires
    narrow_collector's param (List) <: broad_collector's param (Top). Since
    List <: Top, this holds. broad_collector's return (Collection) <: Top also holds.
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "broad_collector->narrow_collector" in pairs, (
        "broad_collector should be assignable to narrow_collector. "
        "A function accepting Top (broader) can substitute for one accepting List (narrower)."
    )


# ============================================================
# TIER 3: Hard (requires fixing the variance bug correctly)
# ============================================================

def test_covariant_false_positive_rejected():
    """json_handler should NOT be assignable to serialize_handler.

    Buggy covariant check says: json_handler(JsonValue)->JsonObject <: serialize_handler(Serializable)->JsonValue
    because JsonValue <: Serializable (param) and JsonObject <: JsonValue (return).
    But CORRECT contravariant check requires: Serializable <: JsonValue for params,
    which is FALSE (Serializable is a SUPERtype of JsonValue, not subtype).
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "json_handler->serialize_handler" not in pairs, (
        "json_handler should NOT be assignable to serialize_handler. "
        "Covariant param check is wrong — parameters are contravariant."
    )


def test_contravariant_true_positive_present():
    """broad_serializer should be assignable to serialize_handler.

    broad_serializer(Top)->JsonValue <: serialize_handler(Serializable)->JsonValue
    Contravariant params: Serializable <: Top ✓ (serialize_handler's param is subtype of broad's)
    Covariant return: JsonValue <: JsonValue ✓ (same type)
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "broad_serializer->serialize_handler" in pairs, (
        "broad_serializer should be assignable to serialize_handler. "
        "With contravariant params: Serializable <: Top holds."
    )


def test_wide_math_assignable_to_number_processor():
    """wide_math (params: Comparable) should be assignable to number_processor (params: Number).

    Contravariant: Number <: Comparable ✓ (Number is subtype of Comparable)
    Covariant: Number <: Number ✓
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "wide_math->number_processor" in pairs, (
        "wide_math should be assignable to number_processor. "
        "Comparable is a supertype of Number (contravariant param check passes)."
    )


# ============================================================
# TIER 4: Hardest (requires all fixes — matrix + fingerprint)
# ============================================================

def test_matrix_true_count():
    """Compatibility matrix must have exactly 29 true entries (excluding self)."""
    report = load_report()
    assert report["matrix_true_count"] == 29, (
        f"Expected 29, got {report['matrix_true_count']}"
    )


def test_fingerprint():
    """Integrity fingerprint must match expected value."""
    report = load_report()
    assert report["fingerprint"] == "f871dc6f87176251", (
        f"Expected 'f871dc6f87176251', got '{report['fingerprint']}'"
    )
