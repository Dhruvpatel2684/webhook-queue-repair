"""
Tests for type-variance-repair task.
Validates the function type assignability analysis output.
"""

import json
import os


RUNTIME_DIR = "/app/runtime"
REPORT_PATH = os.path.join(RUNTIME_DIR, "assignability_report.json")


def load_report():
    """Load assignability_report.json and return dict."""
    with open(REPORT_PATH, "r") as f:
        return json.load(f)


# ============================================================
# TIER 1: Basic structure (pass even with buggy code)
# ============================================================

def test_report_exists():
    """Report file must be created."""
    assert os.path.exists(REPORT_PATH), "assignability_report.json not found"


def test_function_count():
    """Report must contain exactly 20 function definitions."""
    report = load_report()
    assert report["function_count"] == 20, (
        f"Expected 20 functions, got {report['function_count']}"
    )


def test_total_possible_pairs():
    """Total possible pairs must be 20*19=380."""
    report = load_report()
    assert report["total_possible_pairs"] == 380, (
        f"Expected 380, got {report['total_possible_pairs']}"
    )


def test_self_assignable():
    """Every function type must be assignable to itself (reflexive)."""
    report = load_report()
    assert report["self_assignable_count"] == 20, (
        f"Expected 20 self-assignable, got {report['self_assignable_count']}"
    )


def test_report_has_functions():
    """Report must contain per-function analysis for all 20 functions."""
    report = load_report()
    assert "functions" in report
    assert len(report["functions"]) == 20


def test_known_non_assignable():
    """xml_handler should NOT be assignable to integer_processor (unrelated types)."""
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "xml_handler->integer_processor" not in pairs
    assert "integer_processor->xml_handler" not in pairs


def test_assignable_pairs_is_list():
    """Assignable pairs must be a sorted list of strings in 'A->B' format."""
    report = load_report()
    pairs = report["assignable_pairs"]
    assert isinstance(pairs, list)
    assert pairs == sorted(pairs), "Pairs must be sorted"
    for p in pairs:
        assert "->" in p, f"Invalid pair format: {p}"


# ============================================================
# TIER 2: Medium (requires fixing subtype direction)
# ============================================================

def test_assignable_pair_count():
    """Correct analysis must find exactly 29 assignable pairs."""
    report = load_report()
    assert report["assignable_pair_count"] == 29, (
        f"Expected 29 assignable pairs, got {report['assignable_pair_count']}. "
        f"Check both the type hierarchy traversal direction and the "
        f"function compatibility checking logic."
    )


def test_broad_collector_to_narrow_collector():
    """broad_collector(Top)->Collection must be assignable to narrow_collector(List)->Top.

    A function that handles ANY input type can safely replace one that only
    needs to handle Lists. The broader function is strictly more capable.
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "broad_collector->narrow_collector" in pairs, (
        "broad_collector should be assignable to narrow_collector. "
        "A handler accepting Top can safely replace one expecting List."
    )


# ============================================================
# TIER 3: Hard (requires fixing BOTH bugs correctly)
# ============================================================

def test_false_positive_narrow_to_broad():
    """wide_math->integer_processor must NOT be in assignable pairs.

    wide_math(Comparable)->Number CANNOT substitute for integer_processor(Integer)->Integer.
    wide_math returns Number but integer_processor's callers expect Integer specifically.
    Number is NOT a subtype of Integer (it's a supertype).
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "wide_math->integer_processor" not in pairs, (
        "wide_math should NOT be assignable to integer_processor. "
        "The return type Number is not a subtype of Integer."
    )


def test_sequence_sorter_to_list_reverser():
    """sequence_sorter(Sequence)->List must be assignable to list_reverser(List)->Sequence.

    sequence_sorter accepts Sequence (broader than List) so it can handle
    List inputs. Its return (List) is a subtype of Sequence (the expected return).
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "sequence_sorter->list_reverser" in pairs, (
        "sequence_sorter should be assignable to list_reverser."
    )


def test_false_positive_broad_serializer_json():
    """broad_serializer->json_handler must NOT be in assignable pairs.

    broad_serializer(Top)->JsonValue CANNOT substitute for json_handler(JsonValue)->JsonObject.
    broad_serializer returns JsonValue but json_handler's callers expect JsonObject.
    JsonValue is NOT a subtype of JsonObject (it's a supertype).
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "broad_serializer->json_handler" not in pairs, (
        "broad_serializer should NOT be assignable to json_handler. "
        "Return type JsonValue is not a subtype of JsonObject."
    )


def test_utf8_decoder_to_text_formatter():
    """utf8_decoder(Text)->Utf8String must be assignable to text_formatter(Text)->Text.

    Same parameter type (Text). Return Utf8String <: Text holds.
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "utf8_decoder->text_formatter" in pairs, (
        "utf8_decoder should be assignable to text_formatter."
    )


def test_float_caster_to_number_processor():
    """float_caster(Number)->Float must be assignable to number_processor(Number)->Number.

    Same parameter type (Number). Return Float <: Number holds.
    """
    report = load_report()
    pairs = report["assignable_pairs"]
    assert "float_caster->number_processor" in pairs, (
        "float_caster should be assignable to number_processor."
    )


# ============================================================
# TIER 4: Hardest (requires all fixes — matrix + fingerprint)
# ============================================================

def test_matrix_true_count():
    """Compatibility matrix must have exactly 29 true entries (excluding self)."""
    report = load_report()
    assert report["matrix_true_count"] == 29, (
        f"Expected 29, got {report['matrix_true_count']}"
    )


def test_fingerprint():
    """Integrity fingerprint must match expected value."""
    report = load_report()
    assert report["fingerprint"] == "f871dc6f87176251", (
        f"Expected 'f871dc6f87176251', got '{report['fingerprint']}'"
    )
