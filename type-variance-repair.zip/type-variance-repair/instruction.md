# Type Compatibility Checker — Assignability Analysis Broken After Refactor

## What happened

We maintain a type compatibility analysis tool for our plugin system. It determines which callback functions can safely substitute for others based on their type signatures. The tool reads a type hierarchy and function signatures, then computes which functions are assignable to which handler slots.

After a recent refactor that "simplified" the type checking logic, the results are completely wrong. We're getting both false positives (incompatible functions marked as compatible) and false negatives (compatible functions rejected). This caused runtime crashes when incompatible callbacks were plugged into event slots.

## Architecture

Five Python files in `/app/runtime/`:

- `definition_parser.py` — reads `type_definitions.txt`, produces structured type and function definitions (this file is correct)
- `type_registry.py` — maintains the type hierarchy and answers subtype relationship queries
- `variance_checker.py` — determines function type assignability based on subtype rules
- `report_generator.py` — produces the output report (this file is correct)
- `analysis_engine.py` — entry point that wires everything together (this file is correct)

The type definitions file declares a hierarchy of 20 types and 20 function signatures.

## Key principle

When can a function `f` safely replace another function `g`?

The replacement function must be **at least as capable** as the original:
- It must accept **at least** all the inputs that `g` accepts (its input handling must be as broad or broader)
- It must produce outputs that are **at most** as general as what `g` produces (its outputs must be as specific or more specific)

Think of it like a job posting: if someone can do MORE than what's required (broader skills), they're qualified. If they can only do LESS (narrower skills), they're not.

## What's broken

The assignability analysis produces wrong results in multiple ways:

- **Wrong pair count** — 20 pairs reported when 29 are correct
- **False positives** — functions with narrow input acceptance are incorrectly marked as valid substitutes for those with broad acceptance
- **False negatives** — functions with broad input acceptance are incorrectly rejected as substitutes for those with narrow acceptance

For example: `broad_serializer` accepts `Top` (any type) as input. It should be assignable to `serialize_handler` which only needs to handle `Serializable` — if you can handle anything, you can certainly handle serializable data. But the tool says no.

Meanwhile, `serialize_handler` (handles only `Serializable`) is incorrectly marked as assignable to `broad_serializer` (must handle `Top`/anything) — a handler for serializable data can't necessarily handle ALL types.

## Output format

`assignability_report.json` in `/app/runtime/`:

- `function_count` (int): number of function types analyzed (20)
- `total_possible_pairs` (int): N*(N-1) = 380
- `assignable_pair_count` (int): valid assignable pairs
- `assignable_pairs` (list): sorted "source->target" strings
- `self_assignable_count` (int): should be 20 (reflexive)
- `matrix_true_count` (int): true entries excluding self
- `functions` (dict): per-function assignable_to/from lists
- `fingerprint` (string): 16-char hex integrity hash

## How to run

```bash
python3 /app/runtime/analysis_engine.py
```

## What we need

Fix the type checking logic so function assignability is computed correctly. The parser, report generator, and engine are correct — the issues are in how subtype relationships are resolved and how they're applied to determine function compatibility.

Python 3 standard library only.
