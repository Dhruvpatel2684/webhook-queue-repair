# Type Variance Checker — Assignability Analysis Broken After Refactor

## What happened

We maintain a type compatibility analysis tool that determines which function types can safely substitute for others in our event handler system. The tool reads a type hierarchy and a set of function signatures, then computes which functions are assignable to which handler slots.

Last sprint someone refactored the variance checker to "simplify" the subtyping logic. Since then, the assignability results are wrong — we're getting both false positives (functions marked as compatible that shouldn't be) and false negatives (compatible functions being rejected). This caused runtime type errors in production when incompatible handlers were plugged into event slots.

## Architecture

Four Python files in `/app/runtime/`:

- `definition_parser.py` — reads `type_definitions.txt`, produces structured type and function definitions (this file is correct)
- `type_registry.py` — maintains the type hierarchy and answers subtype queries (this file is correct)
- `variance_checker.py` — determines function type assignability using variance rules (this is where the bug is)
- `analysis_engine.py` — entry point that wires everything together (this file is correct)
- `report_generator.py` — produces the output report from analysis results (this file is correct)

The type definitions file declares a hierarchy of 20 types and 20 function signatures. The hierarchy and definitions are correct — don't modify them.

## Type system background

Function type subtyping determines when one function can safely replace another. If you have a handler slot expecting a function of type `(A) -> B`, you can plug in a function of type `(C) -> D` if and only if:

- The replacement function can handle all inputs the original could receive
- The replacement function's output is acceptable wherever the original's output was used

This is the standard Liskov Substitution Principle applied to function types.

## What's broken

The assignability analysis is producing incorrect results:

- **Wrong pair count** — the tool reports 20 assignable pairs when the correct answer is different. Some pairs are falsely included and others are incorrectly excluded.

- **Specific false positives** — functions with narrow parameter types are being marked as assignable to slots with broad parameter types. For example, `json_handler` (taking `JsonValue`) is incorrectly marked as assignable to `serialize_handler` (taking `Serializable`). A handler that only accepts JSON values can't safely replace one that must handle all serializable data.

- **Specific false negatives** — functions with broad parameter types are NOT being marked as assignable to slots with narrow parameter types, when they should be. For example, `broad_collector` (taking `Top`) should be assignable to `narrow_collector` (taking `List`) because a function that handles any type can certainly handle lists.

- **Fingerprint mismatch** — the integrity fingerprint depends on the pair list, so it's wrong as a consequence.

## Output format

The tool produces `assignability_report.json` in `/app/runtime/` with:

- `function_count` (int): number of function types analyzed
- `total_possible_pairs` (int): N*(N-1) possible directed pairs
- `assignable_pair_count` (int): number of valid assignable pairs found
- `assignable_pairs` (list): sorted list of "source->target" strings
- `self_assignable_count` (int): functions assignable to themselves (should be all)
- `matrix_true_count` (int): total true entries excluding self-assignment
- `functions` (dict): per-function analysis with assignable_to and assignable_from lists
- `fingerprint` (string): 16-char hex integrity hash

## How to run

```bash
python3 /app/runtime/analysis_engine.py
```

## What we need

Fix the variance checker in `variance_checker.py` so function type assignability is computed correctly. The type registry, parser, report generator, and engine are all correct — the issue is solely in how the checker determines whether one function type is a subtype of another.

Python 3 standard library only. No external packages needed.
