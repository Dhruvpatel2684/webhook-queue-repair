#!/bin/bash
set -e

# Step 1: Run the broken analysis engine to generate initial (incorrect) output
python3 /app/runtime/analysis_engine.py

# Step 2: Run the repair script which re-analyzes with corrected variance rules:
#   - Fixes parameter checking from covariant to contravariant
#   - Parameters of the supertype function must be subtypes of the subtype's params
python3 /solution/repair_variance.py
