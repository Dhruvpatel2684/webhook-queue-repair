"""
Repair script for type-variance-repair task.
Re-runs the type analysis with corrected logic.

Two fixes applied:
1. type_registry.py bug: _get_all_supertypes traverses SUBTYPES (descendants)
   instead of SUPERTYPES (ancestors). This inverts all subtype relationships.
   Fix: traverse self.supertypes instead of self.subtypes.

2. variance_checker.py bug: Function parameters are checked covariantly
   (same direction) instead of contravariantly (reversed direction).
   Fix: When checking if F <: G, verify that G's param types are subtypes
   of F's param types (not the other way around).

Both bugs interact: the inverted registry + covariant params produces a
double-inversion that accidentally gives some correct results for parameters,
but breaks return type checking. Fixing only one bug makes things worse.
"""

import json
import hashlib
import os
import sys

RUNTIME_DIR = "/app/runtime"
sys.path.insert(0, RUNTIME_DIR)

from definition_parser import parse_definitions


class CorrectTypeRegistry:
    """Type registry with CORRECT supertype traversal."""

    def __init__(self):
        self.supertypes = {}
        self.subtypes = {}
        self._reachable_cache = {}

    def register_type(self, type_name, parents=None):
        if type_name not in self.supertypes:
            self.supertypes[type_name] = set()
            self.subtypes[type_name] = set()
        if parents:
            for parent in parents:
                if parent not in self.supertypes:
                    self.supertypes[parent] = set()
                    self.subtypes[parent] = set()
                self.supertypes[type_name].add(parent)
                self.subtypes[parent].add(type_name)
        self._reachable_cache.clear()

    def is_subtype(self, child, parent):
        if child == parent:
            return True
        return parent in self._get_all_supertypes(child)

    def _get_all_supertypes(self, type_name):
        """FIX: Traverse SUPERTYPES (ancestors), not subtypes (descendants)."""
        if type_name in self._reachable_cache:
            return self._reachable_cache[type_name]
        visited = set()
        # FIX: use self.supertypes (was incorrectly using self.subtypes)
        stack = list(self.supertypes.get(type_name, set()))
        while stack:
            current = stack.pop()
            if current not in visited:
                visited.add(current)
                stack.extend(self.supertypes.get(current, set()))
        self._reachable_cache[type_name] = visited
        return visited


def correct_is_function_subtype(func_sub, func_super, registry):
    """
    Correctly check function subtyping with contravariant parameters.

    FIX: Parameters are CONTRAVARIANT — param_super <: param_sub (reversed)
    Returns are COVARIANT — ret_sub <: ret_super (same direction)
    """
    params_sub = func_sub["params"]
    params_super = func_super["params"]

    if len(params_sub) != len(params_super):
        return False

    # FIX: CONTRAVARIANT parameters: param_super <: param_sub
    for p_sub, p_super in zip(params_sub, params_super):
        if not registry.is_subtype(p_super, p_sub):
            return False

    # COVARIANT return: ret_sub <: ret_super (this was also broken due to inverted registry)
    if not registry.is_subtype(func_sub["returns"], func_super["returns"]):
        return False

    return True


def compute_fingerprint(assignable_pairs, matrix_true_count, function_count):
    data = f"pairs:{len(assignable_pairs)};matrix_true:{matrix_true_count};functions:{function_count};"
    for src, tgt in sorted(assignable_pairs):
        data += f"{src}->{tgt}|"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def main():
    defs_path = os.path.join(RUNTIME_DIR, "type_definitions.txt")
    types, functions = parse_definitions(defs_path)

    # Build CORRECT registry (fixes bug 1)
    registry = CorrectTypeRegistry()
    for name, parents in types:
        registry.register_type(name, parents)

    # Find assignable pairs with CORRECT variance (fixes bug 2)
    assignable_pairs = []
    for i, (name_a, type_a) in enumerate(functions):
        for j, (name_b, type_b) in enumerate(functions):
            if i == j:
                continue
            if correct_is_function_subtype(type_a, type_b, registry):
                assignable_pairs.append((name_a, name_b))

    # Compute compatibility matrix
    compat_matrix = {}
    for name_a, type_a in functions:
        for name_b, type_b in functions:
            compat_matrix[(name_a, name_b)] = correct_is_function_subtype(
                type_a, type_b, registry
            )

    matrix_true_count = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src != tgt
    )
    self_assignable = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src == tgt
    )

    function_count = len(functions)
    total_pairs = function_count * (function_count - 1)
    fingerprint = compute_fingerprint(assignable_pairs, matrix_true_count, function_count)

    # Build per-function info
    func_info = {}
    for name, ftype in functions:
        assignable_to = sorted([tgt for src, tgt in assignable_pairs if src == name])
        assignable_from = sorted([src for src, tgt in assignable_pairs if tgt == name])
        func_info[name] = {
            "params": ftype["params"],
            "returns": ftype["returns"],
            "assignable_to": assignable_to,
            "assignable_from": assignable_from,
        }

    report = {
        "function_count": function_count,
        "total_possible_pairs": total_pairs,
        "assignable_pair_count": len(assignable_pairs),
        "assignable_pairs": sorted([f"{s}->{t}" for s, t in assignable_pairs]),
        "self_assignable_count": self_assignable,
        "matrix_true_count": matrix_true_count,
        "functions": func_info,
        "fingerprint": fingerprint,
    }

    report_path = os.path.join(RUNTIME_DIR, "assignability_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"Repair complete. {len(assignable_pairs)} correct assignable pairs.")


if __name__ == "__main__":
    main()
