"""
Repair script for type-variance-repair task.
Re-runs the type analysis with corrected variance rules.

Fix: Function parameter types are CONTRAVARIANT, not covariant.
When checking if func_sub <: func_super:
  - Parameters: param_SUPER must be subtype of param_SUB (reversed direction)
  - Returns: ret_sub must be subtype of ret_super (same direction)

The buggy code checked params in the SAME direction (covariant),
which is the intuitive but INCORRECT interpretation. The Liskov
Substitution Principle requires contravariance in parameter position:
a function that accepts BROADER inputs (supertypes) can substitute
for one that accepts narrower inputs.
"""

import json
import hashlib
import os
import sys

RUNTIME_DIR = "/app/runtime"
sys.path.insert(0, RUNTIME_DIR)

from definition_parser import parse_definitions
from type_registry import TypeRegistry


def correct_is_function_subtype(func_sub, func_super, registry):
    """
    Correctly check function subtyping with contravariant parameters.

    func_sub <: func_super when:
      - Parameters are CONTRAVARIANT: param_super <: param_sub
        (the subtype function must accept AT LEAST what the supertype accepts,
         meaning its parameter types must be BROADER/supertypes)
      - Return is COVARIANT: ret_sub <: ret_super
        (the subtype function must return AT MOST what the supertype returns,
         meaning its return type must be NARROWER/subtype)
    """
    params_sub = func_sub["params"]
    params_super = func_super["params"]

    if len(params_sub) != len(params_super):
        return False

    # CONTRAVARIANT parameters: param_super <: param_sub (reversed!)
    for p_sub, p_super in zip(params_sub, params_super):
        if not registry.is_subtype(p_super, p_sub):
            return False

    # COVARIANT return: ret_sub <: ret_super
    if not registry.is_subtype(func_sub["returns"], func_super["returns"]):
        return False

    return True


def compute_fingerprint(assignable_pairs, matrix_true_count, function_count):
    data = f"pairs:{len(assignable_pairs)};matrix_true:{matrix_true_count};functions:{function_count};"
    for src, tgt in sorted(assignable_pairs):
        data += f"{src}->{tgt}|"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def main():
    defs_path = os.path.join(RUNTIME_DIR, "type_definitions.txt")
    types, functions = parse_definitions(defs_path)

    registry = TypeRegistry()
    for name, parents in types:
        registry.register_type(name, parents)

    # Find assignable pairs with CORRECT variance
    assignable_pairs = []
    for i, (name_a, type_a) in enumerate(functions):
        for j, (name_b, type_b) in enumerate(functions):
            if i == j:
                continue
            if correct_is_function_subtype(type_a, type_b, registry):
                assignable_pairs.append((name_a, name_b))

    # Compute compatibility matrix
    compat_matrix = {}
    for name_a, type_a in functions:
        for name_b, type_b in functions:
            compat_matrix[(name_a, name_b)] = correct_is_function_subtype(
                type_a, type_b, registry
            )

    matrix_true_count = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src != tgt
    )
    self_assignable = sum(
        1 for (src, tgt), val in compat_matrix.items()
        if val and src == tgt
    )

    function_count = len(functions)
    total_pairs = function_count * (function_count - 1)
    fingerprint = compute_fingerprint(assignable_pairs, matrix_true_count, function_count)

    # Build per-function info
    func_info = {}
    for name, ftype in functions:
        assignable_to = sorted([tgt for src, tgt in assignable_pairs if src == name])
        assignable_from = sorted([src for src, tgt in assignable_pairs if tgt == name])
        func_info[name] = {
            "params": ftype["params"],
            "returns": ftype["returns"],
            "assignable_to": assignable_to,
            "assignable_from": assignable_from,
        }

    report = {
        "function_count": function_count,
        "total_possible_pairs": total_pairs,
        "assignable_pair_count": len(assignable_pairs),
        "assignable_pairs": sorted([f"{s}->{t}" for s, t in assignable_pairs]),
        "self_assignable_count": self_assignable,
        "matrix_true_count": matrix_true_count,
        "functions": func_info,
        "fingerprint": fingerprint,
    }

    report_path = os.path.join(RUNTIME_DIR, "assignability_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    print(f"Repair complete. {len(assignable_pairs)} correct assignable pairs.")


if __name__ == "__main__":
    main()
